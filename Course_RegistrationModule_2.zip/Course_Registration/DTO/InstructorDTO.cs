﻿namespace Course_Registration.DTO
		{
		public class InstructorDTO
				{
				public int Id { get; set; }
				public string FirstName { get; set; }
				public string LastName { get; set; }
				public string EmailAddress { get; set; }
				public string Course { get; set; }
				}
		}
