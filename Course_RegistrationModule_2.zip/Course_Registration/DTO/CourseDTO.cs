﻿namespace Course_Registration.DTO
		{
		public class CourseDTO
				{
				public int Id { get; set; }
				public int CourseNumber { get; set; }
				public string CourseName { get; set; }
				public string Description { get; set; }
				}
		}
